package problemStatement_7;

public class BaseBurger implements Burger {

	@Override
	public String makeBurger() {
		// TODO Auto-generated method stub
		return "Base Burger :";
	}

}
