package problemStatement_3;

public interface IntegerMath {
	  int operation(int a, int b);

}
